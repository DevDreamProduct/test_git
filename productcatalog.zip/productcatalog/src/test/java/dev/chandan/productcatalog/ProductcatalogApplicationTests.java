package dev.chandan.productcatalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductcatalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
